#!/bin/bash
# fail immediately on error
set -e
#key_name=`grep aws_key_name terraform.tfvars | cut -d \" -f2`
region=`grep aws_region terraform.tfvars | cut -d \" -f2`
secret_key=`grep aws_secret_key terraform.tfvars | cut -d \" -f2`
access_key=`grep aws_access_key terraform.tfvars | cut -d \" -f2`

aws configure set aws_access_key_id $access_key
aws configure set aws_secret_access_key $secret_key
aws configure set region $region
aws configure set default.region us-east-1
#echo $key_name
#aws ec2 create-key-pair --key-name ${key_name} --query 'KeyMaterial' --output text > ${key_name}.pem

#!/bin/bash


# fail immediately on error
set -e

# echo "$0 $*" > ~/provision.log

fail() {
  echo "$*" >&2
  exit 1
}

# Variables passed in from terraform, see aws-vpc.tf, the "remote-exec" provisioner
AWS_KEY_ID=${1}
AWS_ACCESS_KEY=${2}
REGION=${3}
VPC=${4}
BOSH_SUBNET=${5}
IPMASK=${6}
CF_IP=${7}
CF_SUBNET1=${8}
CF_SUBNET1_AZ=${9}
CF_SUBNET2=${10}
CF_SUBNET2_AZ=${11}
BASTION_AZ=${12}
BASTION_ID=${13}
LB_SUBNET1=${14}
CF_SG=${15}
CF_ADMIN_PASS=${16}
CF_DOMAIN=${17}
CF_BOSHWORKSPACE_VERSION=${18}
CF_SIZE=${19}
DOCKER_SUBNET=${20}
INSTALL_DOCKER=${21}
CF_RELEASE_VERSION=${22}
DEBUG=${23}
PRIVATE_DOMAINS=${24}
CF_SG_ALLOWS=${25}
CF_RUN_SUBDOMAIN=${26}
CF_APPS_SUBDOMAIN=${27}

INSTALL_LOGSEARCH=${28}
LS1_SUBNET=${29}
LS1_SUBNET_AZ=${30}
BASTION_SUBNET=${32}
BASTION_SG=${31}
AWS_KEY_PATH=${33}
AWS_KEY_NAME=${34}
BOSH_PUBLIC_IP=${35}
ELB_NAME=${36}
CF_SUB_DOMAIN=${37}
AWS_RDS_IP=${38}
CF_VERSION=${39}
ELB_SG=${40}
NAT2_IP=${41}
BOSH_VERSION=${42}
STEM_VERSION=${43}
#echo $CF_VERSION

BACKBONE_Z1_COUNT=COUNT
API_Z1_COUNT=COUNT
SERVICES_Z1_COUNT=COUNT
HEALTH_Z1_COUNT=COUNT
RUNNER_Z1_COUNT=COUNT
BACKBONE_Z2_COUNT=COUNT
API_Z2_COUNT=COUNT
SERVICES_Z2_COUNT=COUNT
HEALTH_Z2_COUNT=COUNT
RUNNER_Z2_COUNT=COUNT

BACKBONE_POOL=POOL
DATA_POOL=POOL
PUBLIC_HAPROXY_POOL=POOL
PRIVATE_HAPROXY_POOL=POOL
API_POOL=POOL
SERVICES_POOL=POOL
HEALTH_POOL=POOL
RUNNER_POOL=POOL

SKIP_SSL_VALIDATION=false

boshDirectorHost="${IPMASK}.1.4"

cd $HOME
(("$?" == "0")) ||
  fail "Could not find HOME folder, terminating install."


if [[ $DEBUG == "true" ]]; then
  set -x
fi

# Generate the key that will be used to ssh between the bastion and the
# microbosh machine
if [[ ! -f ~/.ssh/id_rsa ]]; then
  ssh-keygen -t rsa -N "" -f ~/.ssh/id_rsa
fi

# Prepare the jumpbox to be able to install ruby and git-based bosh and cf repos

release=$(cat /etc/*release | tr -d '\n')
case "${release}" in
  (*Ubuntu*|*Debian*)
    sudo apt-get update -yq
    sudo apt-get install -yq aptitude
    sudo aptitude -yq install build-essential vim-nox git unzip tree \
      libxslt-dev libxslt1.1 libxslt1-dev libxml2 libxml2-dev \
      libpq-dev libmysqlclient-dev libsqlite3-dev \
      g++ gcc make libc6-dev libreadline6-dev zlib1g-dev libssl-dev libyaml-dev \
      libsqlite3-dev sqlite3 autoconf libgdbm-dev libncurses5-dev automake \
      libtool bison pkg-config libffi-dev cmake
    ;;
  (*Centos*|*RedHat*|*Amazon*)
    sudo yum update -y
    sudo yum install -y epel-release
    sudo yum install -y git unzip xz tree rsync openssl openssl-devel \
    zlib zlib-devel libevent libevent-devel readline readline-devel cmake ntp \
    htop wget tmux gcc g++ autoconf pcre pcre-devel vim-enhanced gcc mysql-devel \
    postgresql-devel postgresql-libs sqlite-devel libxslt-devel libxml2-devel \
    yajl-ruby cmake
    ;;
esac

# Install RVM

if [[ ! -d "$HOME/.rvm" ]]; then
  cd $HOME
  gpg --keyserver hkp://keys.gnupg.net --recv-keys 409B6B1796C275462A1703113804BB82D39DC0E3
  curl -sSL https://get.rvm.io | bash -s stable
fi

cd $HOME

if [[ ! "$(ls -A $HOME/.rvm/environments)" ]]; then
  ~/.rvm/bin/rvm install ruby-2.1
fi

if [[ ! -d "$HOME/.rvm/environments/default" ]]; then
  ~/.rvm/bin/rvm alias create default 2.1
fi

source ~/.rvm/environments/default
source ~/.rvm/scripts/rvm



# Install BOSH CLI, bosh-bootstrap, spiff and other helpful plugins/tools
#gem install fog-aws -v 0.1.1 --no-ri --no-rdoc --quiet
#gem install bundler bosh-bootstrap --no-ri --no-rdoc --quiet
sudo apt-get -yq install build-essential ruby ruby-dev libxml2-dev libsqlite3-dev libxslt1-dev libpq-dev libmysqlclient-dev git
gem install bosh_cli bosh_cli_plugin_micro --no-ri --no-rdoc


# We use fog below, and bosh-bootstrap uses it as well
#cat <<EOF > ~/.fog
#:default:
#  :aws_access_key_id: $AWS_KEY_ID
#  :aws_secret_access_key: $AWS_ACCESS_KEY
#  :region: $REGION
#EOF

# This volume is created using terraform in aws-bosh.tf
if [[ ! -d "$HOME/workspace" ]]; then
  sudo /sbin/mkfs.ext4 /dev/xvdc
  sudo /sbin/e2label /dev/xvdc workspace
  echo 'LABEL=workspace /home/ubuntu/workspace ext4 defaults,discard 0 0' | sudo tee -a /etc/fstab
  mkdir -p /home/ubuntu/workspace
  sudo mount -a
  sudo chown -R ubuntu:ubuntu /home/ubuntu/workspace
fi

# As long as we have a large volume to work with, we'll move /tmp over there
# You can always use a bigger /tmp
if [[ ! -d "$HOME/workspace/tmp" ]]; then
  sudo rsync -avq /tmp/ /home/ubuntu/workspace/tmp/
fi

if ! [[ -L "/tmp" && -d "/tmp" ]]; then
  sudo rm -fR /tmp
  sudo ln -s /home/ubuntu/workspace/tmp /tmp
fi

# bosh-bootstrap handles provisioning the microbosh machine and installing bosh
# on it. This is very nice of bosh-bootstrap. Everyone make sure to thank bosh-bootstrap
mkdir -p {bin,workspace/deployments/microbosh,workspace/tools}
pushd workspace/deployments
pushd microbosh
cp /tmp/$AWS_KEY_PATH ./
#cat <<EOF > $AWS_KEY_PATH
#EOF
echo "copied bosh "
create_settings_yml() {
cat <<EOF > settings.yml
---
name: microbosh

network:
  type: manual
 # vip: ${boshDirectorHost} # Replace with your Elastic IP addr
  ip: 10.0.1.6
  dns: [10.0.1.2]
  cloud_properties:
    subnet: ${BOSH_SUBNET} # Replace with your MicroBOSH Subnet ID

resources:
  persistent_disk: 20000
  cloud_properties:
    instance_type: t2.micro
    availability_zone: us-east-1a # Replace with your Availability Zone

cloud:
  plugin: aws
  properties:
    aws:
      access_key_id: ${AWS_KEY_ID} # Replace with your AWSAccessKeyId
      secret_access_key: ${AWS_ACCESS_KEY} # Replace with your AWSSecretKey
      region: ${REGION}
      default_key_name: $AWS_KEY_NAME #Create variable for below 3
      default_security_groups: ["${CF_SG}"]
      ec2_private_key: ./$AWS_KEY_PATH # Path relative to this manifest file

apply_spec:
  agent:
    blobstore: {address: 10.0.1.6}
    nats: {address: 10.0.1.6}
  properties:
    registry: {address: 10.0.1.6}
  hm: {resurrector_enabled: true}
EOF
}
export PATH=/usr/local/bin:$PATH
bosh download public stemcell light-bosh-stemcell-${STEM_VERSION}-aws-xen-hvm-ubuntu-trusty-go_agent.tgz
if [[ ! -f "$HOME/workspace/deployments/microbosh/settings.yml" ]]; then
  create_settings_yml
fi

sudo apt-get install awscli -yq
export AWS_ACCESS_KEY_ID="${AWS_KEY_ID}"
export AWS_SECRET_ACCESS_KEY="${AWS_ACCESS_KEY}"
export AWS_REGION="us-east-1"
##aws configure set region us-east-1


#if [[ ! -d "$HOME/workspace/deployments/microbosh/deployments" ]]; then
  bosh --non-interactive micro deployment settings.yml
  bosh --non-interactive micro deploy light-bosh-stemcell-${STEM_VERSION}-aws-xen-hvm-ubuntu-trusty-go_agent.tgz
#fi


rebuild_micro_bosh_easy() {
  echo "Retry deploying the micro bosh, attempting bosh bootstrap delete..."
  bosh bootstrap delete || rebuild_micro_bosh_hard
  bosh bootstrap deploy
  bosh -n target https://10.0.1.6:25555
  bosh login admin admin
}

rebuild_micro_bosh_hard() {
  echo "Retry deploying the micro bosh, attempting bosh bootstrap delete..."
  rm -rf "$HOME/workspace/deployments/microbosh/deployments"
  rm -rf "$HOME/workspace/deployments/microbosh/ssh"
  create_settings_yml
}

# We've hardcoded the IP of the microbosh machine, because convenience
bosh -n target https://10.0.1.6:25555
bosh login admin admin
bosh upload stemcell light-bosh-stemcell-${STEM_VERSION}-aws-xen-hvm-ubuntu-trusty-go_agent.tgz
popd
popd
mkdir -p {bosh/deployments,bosh/releases,bosh/stemcells}
pushd bosh/deployments
DIRECTOR_UUID=$(bosh status --uuid)

cat <<EOF > bosh.yml
---
name: bosh
director_uuid: ${DIRECTOR_UUID}

release:
  name: bosh
  version: latest

compilation:
  workers: 3
  network: private
  reuse_compilation_vms: true
  cloud_properties:
    instance_type: c3.large

update:
  canaries: 1
  canary_watch_time: 3000-120000
  update_watch_time: 3000-120000
  max_in_flight: 4

networks:
  - name: elastic
    type: vip
    cloud_properties: {}
  - name: private
    type: manual
    subnets:
    - range: 10.0.1.0/24
      reserved:
      - 10.0.1.2 - 10.0.1.7
      static:
      - 10.0.1.71
      gateway: 10.0.1.1
      dns: [10.0.0.2]
      cloud_properties:
        security_groups:
          - ["${CF_SG}"]# CHANGE: Security Group
        subnet:
         ${BOSH_SUBNET}

resource_pools:
  - name: medium
    network: private
    size: 1
    stemcell:
      name: bosh-aws-xen-hvm-ubuntu-trusty-go_agent
      version: latest
    cloud_properties:
      instance_type: t2.micro 
jobs:
  - name: core
    template:
    - powerdns
    - nats
    - postgres
    - redis
    - director
    - blobstore
    - registry
    - health_monitor
    instances: 1
    resource_pool: medium
    persistent_disk: 51200
    networks:
      - name: private
        static_ips:
          - 10.0.1.71
        default: [dns, gateway]
      - name: elastic
        static_ips:
          - ${BOSH_PUBLIC_IP} # CHANGE: Elastic IP 1
      #  cloud_properties: {} 

properties:
  env:

  postgres: &bosh_db
    user: postgres
    password: postges
    host: 10.0.1.71
    listen_address: 10.0.1.71
    database: bosh

  dns:
    address: ${BOSH_PUBLIC_IP} # CHANGE: Elastic IP 1
    db: *bosh_db
    user: powerdns
    password: powerdns
    database:
      name: powerdns
    webserver:
      password: powerdns
    replication:
      basic_auth: replication:zxKDUBeCfKYXk
      user: replication
      password: powerdns
    recursor: 10.0.1.6 # CHANGE: microBOSH IP address

  nats:
    address: 10.0.1.71
    user: nats
    password: nats

  redis:
    address: 10.0.1.71
    password: redis

  director:
    name: bosh
    address: 10.0.1.71
    db: *bosh_db

  blobstore:
    address: 10.0.1.71
    agent:
      user: agent
      password: agent
    director:
      user: director
      password: director

  registry:
    address: 10.0.1.71
    db: *bosh_db
    http:
      user: registry
      password: registry

  hm:
    http:
      user: hm
      password: hm
    director_account:
      user: admin
      password: admin
    event_nats_enabled: false
    email_notifications: false
    tsdb_enabled: false
    pagerduty_enabled: false
    resurrector_enabled: true

  aws:
    access_key_id: ${AWS_KEY_ID} # CHANGE: AWS EC2 access_key_id
    secret_access_key: ${AWS_ACCESS_KEY} # CHANGE: AWS EC2 secret_access_key
    region: ${REGION} # CHANGE: AWS EC2 region
    default_key_name: ${AWS_KEY_NAME} # CHANGE: AWS EC2 default Keyname to use when spinning up new VMs
    default_security_groups: ["${CF_SG}"] # CHANGE: AWS EC2 default Security Groups to use when spinning up new VMs
EOF
popd
pushd bosh/releases
if (aws s3 ls s3://boshexport/release-bosh-${BOSH_VERSION}-on-ubuntu-trusty-stemcell-${STEM_VERSION}.tgz) then
wget https://s3.amazonaws.com/boshexport/release-bosh-${BOSH_VERSION}-on-ubuntu-trusty-stemcell-${STEM_VERSION}.tgz
bosh upload release release-bosh-${BOSH_VERSION}-on-ubuntu-trusty-stemcell-${STEM_VERSION}.tgz
echo "compiled packages exists"
else
echo "Compiled packages doesn't exist"
wget https://s3.amazonaws.com/bosh-jenkins-artifacts/release/bosh-${STEM_VERSION}.tgz
bosh upload release bosh-${STEM_VERSION}.tgz
fi
#wget https://s3.amazonaws.com/boshexport/release-bosh-${BOSH_VERSION}-on-ubuntu-trusty-stemcell-${STEM_VERSION}.tgz
#bosh upload release release-bosh-${BOSH_VERSION}-on-ubuntu-trusty-stemcell-${STEM_VERSION}.tgz
#wget https://s3.amazonaws.com/bosh-jenkins-artifacts/release/bosh-${STEM_VERSION}.tgz
#bosh upload release bosh-${STEM_VERSION}.tgz
popd
pushd bosh/deployments
#bosh --non-interactive deploy
bosh --non-interactive deployment bosh.yml
bosh --non-interactive deploy

if [[ ! "$?" == 0 ]]; then
  #wipe the ~/workspace/deployments/microbosh folder contents and try again
  echo "Retry deploying the micro bosh..."
fi
popd

# There is a specific branch of cf-boshworkspace that we use for terraform. This
# may change in the future if we come up with a better way to handle maintaining
# configs in a git repo
#if [[ ! -d "$HOME/workspace/deployments/cf-boshworkspace" ]]; then
#  git clone --branch  ${CF_BOSHWORKSPACE_VERSION} http://github.com/cloudfoundry-community/cf-boshworkspace
#fi
#pushd cf-boshworkspace
#mkdir -p ssh
#gem install bundler
#bundle install
sudo apt-get install postgresql-client -yq
#sudo useradd vcap -p c1oudc0w
#$sudo su -
#$su - vcap
cat <<EOF > a.sql
create database uaadb ;
\connect uaadb ;
CREATE EXTENSION IF NOT EXISTS citext;
create role vcap  password 'c1oudc0w';
alter role vcap CREATEROLE CREATEDB LOGIN;
alter role  vcap  VALID UNTIL 'infinity';
alter database uaadb owner to vcap;
create database ccdb ;
\connect ccdb;
CREATE EXTENSION IF NOT EXISTS citext;
alter database ccdb owner to vcap;
EOF
export PGPASSWORD=c1oudc0w
psql -h ${AWS_RDS_IP} -p 5432 -d postgres -f a.sql
bosh -n target https://10.0.1.71:25555
bosh login admin admin
mkdir -p {cf/deployments,cf/releases,cf/stemcells}
#git clone https://github.com/cloudfoundry/cf-release.git
pushd cf/releases
git clone https://github.com/cloudfoundry/cf-release.git
pushd cf-release
./scripts/update
bosh upload stemcell /home/ubuntu/workspace/deployments/microbosh/light-bosh-stemcell-${STEM_VERSION}-aws-xen-hvm-ubuntu-trusty-go_agent.tgz
#bosh upload release /home/ubuntu/cf/releases/cf-release/releases/cf-${CF_VERSION}.yml

if (aws s3 ls s3://boshexport/release-cf-${CF_VERSION}-on-ubuntu-trusty-stemcell-${STEM_VERSION}.tgz) then
wget https://s3.amazonaws.com/boshexport/release-cf-${CF_VERSION}-on-ubuntu-trusty-stemcell-${STEM_VERSION}.tgz
bosh upload release release-cf-${CF_VERSION}-on-ubuntu-trusty-stemcell-${STEM_VERSION}.tgz
echo "compiled packages exists"
else
echo "Compiled packages doesn't exist"
bosh upload release /home/ubuntu/cf/releases/cf-release/releases/cf-${CF_VERSION}.yml
fi
#wget https://s3.amazonaws.com/boshexport/release-cf-${CF_VERSION}-on-ubuntu-trusty-stemcell-${STEM_VERSION}.tgz
#bosh upload release release-cf-${CF_VERSION}-on-ubuntu-trusty-stemcell-${STEM_VERSION}.tgz
BOSH_DIRECTOR_UUID=$(bosh status --uuid)
popd
popd
pushd cf/deployments
git clone https://github.com/MonsantoCo/CF_MANIFEST_AWS.git
pushd CF_MANIFEST_AWS
/bin/sed -i \
  -e "s/BOSH_DIRECTOR_UUID/${BOSH_DIRECTOR_UUID}/g" \
  -e "s/CF_SUBNET1/${CF_SUBNET1}/g" \
  -e "s/CF_SUBNET2/${CF_SUBNET2}/g" \
  -e "s/BASTION_SG/${BASTION_SG}/g" \
  -e "s/BASTION_SUBNET/${BASTION_SUBNET}/g" \
  -e "s/ELB_NAME/${ELB_NAME}/g" \
  -e "s/AWS_KEY_ID/${AWS_KEY_ID}/g" \
  -e "s/AWS_ACCESS_KEY/${AWS_ACCESS_KEY}/g" \
  -e "s/CF_SUB_DOMAIN/${CF_SUB_DOMAIN}/g" \
  -e "s/AWS_RDS_IP/${AWS_RDS_IP}/g" \
  -e "s/AWS_KEY_NAME/${AWS_KEY_NAME}/g" \
  -e "s/CF_VERSION/${CF_VERSION}/g" \
  -e "s/STEM_VERSION/${STEM_VERSION}/g" \
  cf_np.yml
bosh deployment cf_np.yml
for i in {0..2}
do bosh -n deploy
done
#bosh -n deploy
popd
# Pull out the UUID of the director - bosh_cli needs it in the deployment to
# know it's hitting the right microbosh instance
#DIRECTOR_UUID=$(bosh status --uuid)


# If CF_DOMAIN is set to XIP, then use XIP.IO. Otherwise, use the variable
#if [[ $CF_DOMAIN == "XIP" ]]; then
#  CF_DOMAIN="${CF_IP}.xip.io"
#  SKIP_SSL_VALIDATION="true"
#fi


# If CF_RUN_SUBDOMAIN is set, then use it's value to replace the default subdomain. Otherwise (if empty), don't use a subdomain
#if [[ -n "$CF_RUN_SUBDOMAIN" ]]; then
#  CF_RUN_SUBDOMAIN_SED_EXPRESSION="s/run.CF_DOMAIN/${CF_RUN_SUBDOMAIN}.${CF_DOMAIN}/g"
#else
#  CF_RUN_SUBDOMAIN_SED_EXPRESSION="s/run.CF_DOMAIN/${CF_DOMAIN}/g"
#fi

# If CF_APPS_SUBDOMAIN is set, then use it's value to replace the default subdomain. Otherwise (if empty), don't use a subdomain
#if [[ -n "$CF_APPS_SUBDOMAIN" ]]; then
#  CF_APPS_SUBDOMAIN_SED_EXPRESSION="s/apps.CF_DOMAIN/${CF_APPS_SUBDOMAIN}.${CF_DOMAIN}/g"
#else
#  CF_APPS_SUBDOMAIN_SED_EXPRESSION="s/apps.CF_DOMAIN/${CF_DOMAIN}/g"
#fi

# This is some hackwork to get the configs right. Could be changed in the future
#/bin/sed -i \
#  -e "s/runner:\( \+\)[a-z\-\_A-Z0-1]\+\(.*# MARKER_FOR_POOL_PROVISION.*\)/runner:\1${RUNNER_POOL}\2/" \
#  deployments/cf-aws-${CF_SIZE}.yml

#if [[ -n "$PRIVATE_DOMAINS" ]]; then
#  for domain in $(echo $PRIVATE_DOMAINS | tr "," "\n"); do
#    sed -i -e "s/^\(\s\+\)- PRIVATE_DOMAIN_PLACEHOLDER/\1- $domain\n\1- PRIVATE_DOMAIN_PLACEHOLDER/" deployments/cf-aws-${CF_SIZE}.yml
#  done
#  sed -i -e "s/^\s\+- PRIVATE_DOMAIN_PLACEHOLDER//" deployments/cf-aws-${CF_SIZE}.yml
#else
#  sed -i -e "s/^\(\s\+\)internal_only_domains:\$/\1internal_only_domains: []/" deployments/cf-aws-${CF_SIZE}.yml
#  sed -i -e "s/^\s\+- PRIVATE_DOMAIN_PLACEHOLDER//" deployments/cf-aws-${CF_SIZE}.yml
#fi

#if [[ -n "$CF_SG_ALLOWS" ]]; then
#  replacement_text=""
#  for cidr in $(echo $CF_SG_ALLOWS | tr "," "\n"); do
#    if [[ -n "$cidr" ]]; then
#      replacement_text="${replacement_text}{\"protocol\":\"all\",\"destination\":\"${cidr}\"},"
#    fi
#  done
#  if [[ -n "$replacement_text" ]]; then
#    replacement_text=$(echo $replacement_text | sed 's/,$//')
#    sed -i -e "s|^\(\s\+additional_security_group_rules:\s\+\).*|\1[$replacement_text]|" deployments/cf-aws-${CF_SIZE}.yml
#  fi

# Upload the bosh release, set the deployment, and execute
#bosh upload release --skip-if-exists https://bosh.io/d/github.com/cloudfoundry/cf-release?v=${CF_RELEASE_VERSION}
#bosh deployment cf-aws-${CF_SIZE}
#bosh prepare deployment || bosh prepare deployment  #Seems to always fail on the first run...

# Keep trying until there is a successful BOSH deploy.
#for i in {0..2}
#do bosh micro deploy
#done

# Run smoke tests disabled - running into intermittent failures
#bosh run errand smoke_tests_runner

#fi

echo "Provision script completed..."
exit 0

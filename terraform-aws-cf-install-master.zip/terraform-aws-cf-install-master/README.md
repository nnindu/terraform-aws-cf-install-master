
# terraform-aws-cf-install
Mon terraform AWS CF


terraform-aws-cf-install 
========================

This is part of a project that aims to create a one click deploy of Cloud Foundry in two availability zones into an AWS VPC (Including Microbosh and bosh)

Architecture
------------


We rely on two other repositories to do the bulk of the work. The [terraform-aws-vpc](https://github.com/MonsantoCo/terraform-aws-vpc) repo creates the base VPC infrastructure, including a bastion subnet, the`microbosh` subnet, a NAT server, various route tables, and the VPC itself. Then the [terraform-aws-cf-net](https://github.com/MonsantoCo/terraform-aws-cf-net) repo creates a loadbalancer subnet, two runtime subnets, `cf` related security groups, and the elastic IP used by `cf` and elb. This gives us the flexibility to use the`terraform-aws-cf-net` module multiple times, to have a staging and production cf within the same VPC, sharing a single microbosh/bosh instance.


Deploy Cloud Foundry
--------------------

### Prerequisites


You **must** being using at least terraform version 0.6.0.

```
$ terraform -v
Terraform v0.6.3
```

You can install terraform 0.6.0+ via [https://www.terraform.io/downloads.html]

Your chosen AWS Region must have sufficient quota to spin up **all** of the machines. While building various bits, the install process can use up to 30 VMs, settling down to use 24 machines long-term (more, if you want more runners).

Install aws_cli ( http://docs.aws.amazon.com/cli/latest/userguide/installing.html)

#### NOTE: Building the entire Cloud Foundry cluster will take a little over an hour! It hasn't hung (probably), it just takes a little while to do ALL THE THINGS.

### Unattended install

```bash
git clone https://github.com/MonsantoCo/terraform-aws-cf-install
cd terraform-aws-cf-install
cp terraform.tfvars.example terraform.tfvars
```

Next, edit `terraform.tfvars` using your text editor and fill out the variables with your own values (AWS credentials, AWS region,cf-Sub_domain,cf-version etc).

Run the following to create the AWS keys to access ec2 instances,networking, subnets, security groups, ports ,create a bastion server, and deploy bosh/microbosh/CF ( Make sure you can run terraform..If not export path to terraform install location)

```bash
make all
```
*****************************

make all in turn calls following..
```bash
make createkey  
make plan
make apply
```

Once the bastion server is created, run the following to create a provision script with all the variables assigned, copy the script to the Bastion server then remotely execute the script.  This allows the script to be executed multiple times, as needed, without needing to destroy the Bastion server.

```bash
make provision
```

If the provision script fails, run `make provision` again from your laptop.  If you want someone to help you, a full copy of the provision script is also on the Bastion server at `/home/ubuntu/provision.sh`

After Initial Install
---------------------

At the end of the output of the terraform run, there will be a section called `Outputs` that will have at least `bastion_ip` and an IP address. If not, or if you cleared the terminal without noting it, you can log into the AWS console and look for an instance called 'bastion', with the `bastion` security group. Use the public IP associated with that instance, and ssh in as the ubuntu user, using the ssh key listed as `aws_key_path` in your configuration (if you used the Unattended Install).

```
ssh -i ~/.ssh/example.pem ubuntu@$(terraform output bastion_ip)
```

As an alternative there is a script provided for you which will execute ssh with all the necessary parameters.  From the root of the project folder run

```
make ssh
```

Once in, you can look in `/home/ubuntu/workspace/deployments/microbosh/` or  `/home/ubuntu/bosh/deployments` for the microbosh/bosh deployment manifest and template files. Any further updates or changes to your microbosh or Cloud Foundry environment will be done manually using this machine as your work space. Terraform provisioning scripts are not intended for long-term updates or maintenance.

Cloud Foundry
-------------

To login to Cloud Foundry as an administrator:

```
cf login --skip-ssl-validation -a API_URL -u admin -p $(terraform output cf_admin_pass)
```

You can also log into the cf api from the inception server itself, though you have to manually replace the calls to terraform from above with the actual values.

Cleanup / Tear down
-------------------

Terraform does not yet quite cleanup after itself. You can run `make destroy` to get quite a few of the resources you created, but you will probably have to manually track down some of the bits and manually remove them. Once you have done so, run `make clean` to remove the local cache and status files, allowing you to run everything again without errors.


### Configuration

Look in `variables.tf` to see all of the variables that can be set or overriden. The mandatory variables are:

```
source = "github.com/MpnsantoCo/terraform-aws-cf-install" # Or your own source, if you fork the repo
aws_access_key = "${var.aws_access_key}" # Provided by Amazon
aws_secret_key = "${var.aws_secret_key}" # Provided by Amazon
aws_key_name = "${var.aws_key_name}" # The "name" of the ssh key to use in the AWS Console under EC2 -> Network & Security -> Key Pairs
aws_key_path = "${var.aws_key_path}" # Literal path to pem file on the computer running Terraform - /home/user/keys/exapmle.pem
network = "${var.network}" # The first two octects to use within the VPC, e.g. 10.0 or 10.10
```


